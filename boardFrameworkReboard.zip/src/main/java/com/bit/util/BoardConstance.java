package com.bit.util;

public class BoardConstance {

	//한 페이지당 게시글 몇 개씩 노출할 것인지
	public final static int LIST_COUNT=20;
	
	public final static int PAGE_COUNT=10;
	
}
