package com.bit.board.admin.model;

public class BoardTypeDto {
	
	private int btype;
	private String btypeName;
	
	
	public int getBtype() {
		return btype;
	}
	public void setBtype(int btype) {
		this.btype = btype;
	}
	public String getBtypeName() {
		return btypeName;
	}
	public void setBtypeName(String btypeName) {
		this.btypeName = btypeName;
	}
	
	
	
}
